/*
*With this Java Class you can validate your input, test its and make a comparison.
*Now you can valid your GUI Input Fields easier.
*This Class all method Static, implemented to help you to be saved from any wrong counted in your App.
*Also, it support Float, Integer All kind of Types with More Flexibility.
*/
package validmf;

import java.util.ArrayList;

/**
 *
 * @author Muhammad M. Fadel This Class Created To Check If The Index In The
 * ArrayList Is a Number Or Not So to use it should create ArrayList and send
 * the value you need to check as an index value.
 */
public class validNumMF {

    //this array contain the numbers which we will compare with
    private static final char numSym[] = {'+', '-', '.', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

    public validNumMF() {}

    //This method for checking if the received value is a number or not 
    static boolean isNumber(Object number) {
        boolean succ = false;
        int sign = 0;
        int dot = 0;

        //here we will split the string to seperate characters
        String index = number.toString();
        
        //checking of the number size after casceding it
        for (int c = 0; c < index.length(); c++) {
            for (int y = 0; y < numSym.length; y++) {
                if (index.charAt(c) == numSym[y]) {
                    //To check if the number has more than one character
                    if (index.charAt(c) == '-' || index.charAt(c) == '+') {
                        sign++;
                    }
                    if (index.charAt(c) == '.') {
                        dot++;
                    }
                    //End of checking signs
                    succ = true;
                }
            }
            if (succ != true || sign > 1 || dot > 1) {
                return false;
            }
        }
        return true;
    }

    //This method to Check if the Number is positive or not
    static boolean isPositiveNumber(Object number) {
        //Check is a Valid Number Firstly
        boolean succ = isNumber(number.toString());

        if (succ) { //if it a Valid Number
            if (Float.parseFloat(number.toString()) > 0) {  //Check if it a positive or not
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    //Method To Check if the Created ArrayList is full of Numbers or not
    static boolean isArrayListOfNumbers(ArrayList<Object> array_numbers) {
        if (!array_numbers.isEmpty()) {
            for (int i = 0; i < array_numbers.size(); i++) {
                //here we will split the string to seperate characters
                String index = array_numbers.get(i).toString();

                //checking of the index
                if (!isNumber(index)) {
                    return false;
                }

            }
            return true;
        }
        return false;
    }//MethodClosing

    //This Method To Check if the number is Bigger Than The Value or not
    static boolean BTN(Object number, Object value) {
        //Check is it a valid Number Firstly
        boolean succ = isNumber(number.toString());

        if (succ) {
            if (Float.parseFloat(number.toString()) > Float.parseFloat(value.toString())) {  //Check if it a positive or not
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    //This Method To Check if the number is Bigger Than The Value or not
    static boolean NIR(Object number, Object from, Object to) {
        //Check is it a valid Number Firstly
        boolean succ = isNumber(number.toString());

        if (succ) {
            if (Float.parseFloat(number.toString()) > Float.parseFloat(from.toString())
                    && Float.parseFloat(number.toString()) < Float.parseFloat(to.toString())) {  //Check if it IN THE RANGE OR NOT
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

}//class closing
